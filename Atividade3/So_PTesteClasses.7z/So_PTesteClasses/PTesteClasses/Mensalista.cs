﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Threading.Tasks;

namespace PTesteClasses
{
    internal class Mensalista:Empregado
    {
        public Double SalarioMensal { get; set; }

        //sobrequevendo o método
        public override double SalarioBruto()
        {
            return SalarioMensal;
        }

        public Mensalista(int maxt, string nomex, DateTime datax, double salariox)
        {
            this.NomeEmpregado = nomex;
            this.Matricula = maxt;
            this.DataEntradaEmpresa = datax;
            this.SalarioMensal = salariox;
        }
    }
}
